(() => {
  if (window.hasWaterBallExtension) {
    console.log("Water ball extension already loaded");
    const existingWaterBall = document.querySelector(".water-ball-container");
    if (existingWaterBall) {
      existingWaterBall.remove();
    }
  }
  console.log("Initializing water ball extension...");
  Object.defineProperty(window, "hasWaterBallExtension", {
    value: true,
    enumerable: false,
    writable: false
  });
  let waterBallContainer = null;
  let isVisible = false;
  let yearProgress = 0;
  let updateInterval = null;
  let observer = null;
  let currentPosition = { right: "20px", bottom: "20px", left: "auto", top: "auto" };
  function calculateYearProgress() {
    const now = /* @__PURE__ */ new Date();
    const year = now.getFullYear();
    const startOfYear = new Date(year, 0, 1);
    const endOfYear = new Date(year + 1, 0, 1);
    const totalMilliseconds = endOfYear - startOfYear;
    const elapsedMilliseconds = now - startOfYear;
    return elapsedMilliseconds / totalMilliseconds * 100;
  }
  function calculateDayProgress() {
    const now = /* @__PURE__ */ new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const endOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    const totalMilliseconds = endOfDay - startOfDay;
    const elapsedMilliseconds = now - startOfDay;
    return elapsedMilliseconds / totalMilliseconds * 100;
  }
  function createWaterBall() {
    const existingWaterBall = document.querySelector(".water-ball-container");
    if (existingWaterBall) {
      existingWaterBall.remove();
    }
    if (waterBallContainer)
      return;
    console.log("Creating water ball...");
    try {
      waterBallContainer = document.createElement("div");
      waterBallContainer.className = "water-ball-container";
      Object.keys(currentPosition).forEach((key) => {
        waterBallContainer.style[key] = currentPosition[key];
      });
      waterBallContainer.innerHTML = `
                <div class="water-balls-wrapper">
                    <div class="water-ball year-ball">
                        <div class="water-wave"></div>
                        <div class="percentage-container">
                            <div class="label">年进度</div>
                            <div class="percentage">0%</div>
                        </div>
                    </div>
                    <div class="water-ball day-ball">
                        <div class="water-wave"></div>
                        <div class="percentage-container">
                            <div class="label">日进度</div>
                            <div class="percentage">0%</div>
                        </div>
                    </div>
                </div>
            `;
      let isDragging = false;
      let startX = 0;
      let startY = 0;
      let initialX = 0;
      let initialY = 0;
      waterBallContainer.addEventListener("mousedown", (e) => {
        isDragging = true;
        startX = e.clientX;
        startY = e.clientY;
        const rect = waterBallContainer.getBoundingClientRect();
        initialX = rect.left;
        initialY = rect.top;
        e.preventDefault();
      });
      document.addEventListener("mousemove", (e) => {
        if (!isDragging)
          return;
        const dx = e.clientX - startX;
        const dy = e.clientY - startY;
        const newLeft = initialX + dx;
        const newTop = initialY + dy;
        waterBallContainer.style.left = `${newLeft}px`;
        waterBallContainer.style.top = `${newTop}px`;
        waterBallContainer.style.right = "auto";
        waterBallContainer.style.bottom = "auto";
        currentPosition = {
          left: `${newLeft}px`,
          top: `${newTop}px`,
          right: "auto",
          bottom: "auto"
        };
      });
      document.addEventListener("mouseup", () => {
        if (isDragging) {
          isDragging = false;
          try {
            chrome.runtime.sendMessage({
              action: "saveWaterBallPosition",
              position: currentPosition
            });
          } catch (e) {
            console.error("Failed to save water ball position:", e);
          }
        }
      });
      try {
        document.body.appendChild(waterBallContainer);
        console.log("Water ball created and added to page");
        setupObserver();
      } catch (e) {
        console.error("Failed to append water ball to body:", e);
      }
    } catch (e) {
      console.error("Error creating water ball:", e);
    }
  }
  function updateWaterBallPosition(position) {
    if (!waterBallContainer)
      return;
    Object.keys(position).forEach((key) => {
      waterBallContainer.style[key] = position[key];
    });
    currentPosition = position;
  }
  function setupObserver() {
    if (observer) {
      observer.disconnect();
    }
    observer = new MutationObserver((mutations) => {
      if (isVisible && waterBallContainer && !document.body.contains(waterBallContainer)) {
        try {
          document.body.appendChild(waterBallContainer);
          console.log("Water ball re-added to page after DOM change");
        } catch (e) {
          console.error("Failed to re-append water ball:", e);
        }
      }
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }
  function updateWaterBall() {
    if (!waterBallContainer || !isVisible)
      return;
    yearProgress = calculateYearProgress();
    const dayProgress = calculateDayProgress();
    const yearWave = waterBallContainer.querySelector(".year-ball .water-wave");
    const yearPercentage = waterBallContainer.querySelector(".year-ball .percentage");
    const dayWave = waterBallContainer.querySelector(".day-ball .water-wave");
    const dayPercentage = waterBallContainer.querySelector(".day-ball .percentage");
    if (yearWave && yearPercentage) {
      yearWave.style.height = `${yearProgress}%`;
      yearWave.style.top = "auto";
      yearWave.style.bottom = "0";
      const yearColor = getColorByPercentage(yearProgress);
      yearWave.style.background = yearColor;
      yearPercentage.textContent = `${yearProgress.toFixed(1)}%`;
    }
    if (dayWave && dayPercentage) {
      dayWave.style.height = `${dayProgress}%`;
      dayWave.style.top = "auto";
      dayWave.style.bottom = "0";
      const dayColor = getDayColorByPercentage(dayProgress);
      dayWave.style.background = dayColor;
      dayPercentage.textContent = `${dayProgress.toFixed(1)}%`;
    }
  }
  function getColorByPercentage(percentage) {
    if (percentage < 25) {
      return "#81C784";
    } else if (percentage < 50) {
      return "#66BB6A";
    } else if (percentage < 75) {
      return "#4CAF50";
    } else {
      return "#388E3C";
    }
  }
  function getDayColorByPercentage(percentage) {
    if (percentage < 25) {
      return "#90CAF9";
    } else if (percentage < 50) {
      return "#64B5F6";
    } else if (percentage < 75) {
      return "#42A5F5";
    } else {
      return "#1E88E5";
    }
  }
  function showWaterBall() {
    console.log("Showing water ball...");
    if (!waterBallContainer) {
      createWaterBall();
    }
    if (waterBallContainer) {
      console.log("Setting water ball display to block");
      waterBallContainer.style.display = "block";
      waterBallContainer.style.visibility = "visible";
      waterBallContainer.style.opacity = "1";
      isVisible = true;
      updateWaterBall();
      if (!updateInterval) {
        updateInterval = setInterval(updateWaterBall, 1e3);
      }
      if (!document.body.contains(waterBallContainer)) {
        try {
          console.log("Appending water ball to body");
          document.body.appendChild(waterBallContainer);
        } catch (e) {
          console.error("Failed to append water ball when showing:", e);
        }
      }
      console.log("Water ball container:", waterBallContainer);
      console.log("Water ball style:", waterBallContainer.style.cssText);
      console.log("Water ball is in DOM:", document.body.contains(waterBallContainer));
      console.log("Water ball dimensions:", waterBallContainer.getBoundingClientRect());
      console.log("Water ball computed style:", window.getComputedStyle(waterBallContainer));
    } else {
      console.error("Failed to create water ball container");
    }
  }
  function hideWaterBall() {
    if (waterBallContainer) {
      waterBallContainer.style.display = "none";
      isVisible = false;
      if (updateInterval) {
        clearInterval(updateInterval);
        updateInterval = null;
      }
    }
  }
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("Received message:", request);
    if (request.action === "toggleWaterBall") {
      if (request.show) {
        showWaterBall();
      } else {
        hideWaterBall();
      }
      sendResponse({ success: true });
      return true;
    }
    if (request.action === "updateWaterBall") {
      if (request.show) {
        showWaterBall();
      } else {
        hideWaterBall();
      }
      if (request.position) {
        updateWaterBallPosition(request.position);
      }
      sendResponse({ success: true });
      return true;
    }
  });
  try {
    chrome.runtime.sendMessage({ action: "getWaterBallState" }, (response) => {
      console.log("Initial water ball state from background:", response);
      if (response) {
        if (response.position) {
          currentPosition = response.position;
        }
        if (response.show) {
          showWaterBall();
        }
      } else {
        showWaterBall();
      }
    });
  } catch (e) {
    console.error("Error getting water ball state from background:", e);
    showWaterBall();
  }
  window.addEventListener("load", () => {
    if (isVisible) {
      showWaterBall();
    }
  });
  const style = document.createElement("style");
  style.textContent = `
        .water-ball-container {
            position: fixed;
            width: 170px; /* 减小整体宽度 */
            height: 80px; /* 减小整体高度 */
            z-index: 2147483647;
            cursor: move;
            user-select: none;
            pointer-events: auto !important;
            display: block; /* 确保可见 */
        }
        .water-balls-wrapper {
            display: flex;
            gap: 10px;
            width: 100%;
            height: 100%;
        }
        .water-ball {
            width: 80px; /* 减小水球尺寸 */
            height: 80px; /* 减小水球尺寸 */
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.9); /* 增加不透明度 */
            box-shadow: 0 3px 12px rgba(0,0,0,0.15); /* 改进阴影效果 */
            overflow: hidden;
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: transform 0.2s ease; /* 添加悬停动画 */
        }
        .water-ball:hover {
            transform: scale(1.05); /* 悬停时轻微放大 */
        }
        .water-wave {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            transition: height 0.3s ease;
            overflow: hidden;
        }
        .water-wave::before,
        .water-wave::after {
            content: "";
            position: absolute;
            width: 200%;
            height: 8px;
            top: -4px;
            left: -50%;
            background: transparent;
            border-radius: 40%;
        }
        .water-wave::before {
            animation: wave-x 3s infinite linear, wave-y 2.5s infinite ease-in-out;
            border-top: 2px solid rgba(255, 255, 255, 0.5); /* 增加波浪可见度 */
        }
        .water-wave::after {
            animation: wave-x 3s infinite linear reverse, wave-y 3s infinite ease-in-out -1.25s;
            border-top: 2px solid rgba(255, 255, 255, 0.3);
        }
        .percentage-container {
            position: relative;
            z-index: 1;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
        }
        .label {
            font-size: 10px; /* 减小标签字体 */
            color: #333;
            margin-bottom: 2px;
            text-shadow: 0 1px 2px rgba(255, 255, 255, 0.6);
            font-weight: 500;
        }
        .percentage {
            font-size: 16px; /* 减小百分比字体 */
            font-weight: bold;
            color: #333;
            text-shadow: 0 1px 2px rgba(255, 255, 255, 0.6);
        }
        @keyframes wave-x {
            0% {
                transform: translateX(-50%);
            }
            100% {
                transform: translateX(0);
            }
        }
        @keyframes wave-y {
            0%, 100% {
                transform: translateY(-2px);
            }
            50% {
                transform: translateY(2px);
            }
        }
        /* 添加一个淡入效果 */
        .water-ball-container {
            opacity: 0;
            animation: fade-in 0.5s ease forwards;
        }
        @keyframes fade-in {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    `;
  document.head.appendChild(style);
})();
//# sourceMappingURL=waterball.js.map
