let showWaterBall = true;
let waterBallPosition = { right: "20px", bottom: "20px", left: "auto", top: "auto" };
chrome.storage.sync.get(["showWaterBall", "waterBallPosition"], (data) => {
  if (data.showWaterBall !== void 0) {
    showWaterBall = data.showWaterBall;
  } else {
    chrome.storage.sync.set({ showWaterBall: true });
  }
  if (data.waterBallPosition) {
    waterBallPosition = data.waterBallPosition;
  } else {
    chrome.storage.sync.set({ waterBallPosition });
  }
  updateExtensionIcon();
  if (showWaterBall) {
    syncWaterBallToAllTabs();
  }
});
function updateExtensionIcon() {
  const now = /* @__PURE__ */ new Date();
  const year = now.getFullYear();
  const startOfYear = new Date(year, 0, 1);
  const endOfYear = new Date(year + 1, 0, 1);
  const totalMilliseconds = endOfYear - startOfYear;
  const elapsedMilliseconds = now - startOfYear;
  const yearProgress = elapsedMilliseconds / totalMilliseconds * 100;
  const canvas = new OffscreenCanvas(128, 128);
  const ctx = canvas.getContext("2d");
  ctx.beginPath();
  ctx.arc(64, 64, 60, 0, 2 * Math.PI);
  ctx.fillStyle = "white";
  ctx.fill();
  ctx.strokeStyle = "#2196F3";
  ctx.lineWidth = 2;
  ctx.stroke();
  const waterHeight = 120 * (yearProgress / 100);
  ctx.beginPath();
  ctx.rect(4, 128 - waterHeight, 120, waterHeight);
  ctx.fillStyle = "#29b6f6";
  ctx.fill();
  ctx.font = "bold 24px Arial";
  ctx.fillStyle = "#333";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(`${yearProgress.toFixed(1)}%`, 64, 64);
  const imageData = ctx.getImageData(0, 0, 128, 128);
  chrome.action.setIcon({ imageData });
  chrome.action.setBadgeText({ text: showWaterBall ? "" : "OFF" });
  chrome.action.setBadgeBackgroundColor({ color: "#F44336" });
}
function syncWaterBallToAllTabs() {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      if (tab.url && tab.url.startsWith("http")) {
        try {
          chrome.tabs.sendMessage(tab.id, {
            action: "updateWaterBall",
            show: showWaterBall,
            position: waterBallPosition
          }).catch(() => {
            console.log(`Failed to send message to tab ${tab.id}, injecting script...`);
          });
        } catch (e) {
          console.error(`Error sending message to tab ${tab.id}:`, e);
        }
      }
    });
  });
}
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url && tab.url.startsWith("http")) {
    try {
      chrome.tabs.sendMessage(tabId, {
        action: "updateWaterBall",
        show: showWaterBall,
        position: waterBallPosition
      }).catch(() => {
      });
    } catch (e) {
      console.error(`Error sending message to updated tab ${tabId}:`, e);
    }
  }
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getWaterBallState") {
    sendResponse({
      show: showWaterBall,
      position: waterBallPosition
    });
    return true;
  }
  if (request.action === "setWaterBallState") {
    showWaterBall = request.show;
    chrome.storage.sync.set({ showWaterBall });
    updateExtensionIcon();
    syncWaterBallToAllTabs();
    sendResponse({ success: true });
    return true;
  }
  if (request.action === "updateWaterBallPosition") {
    waterBallPosition = request.position;
    chrome.storage.sync.set({ waterBallPosition });
    syncWaterBallToAllTabs();
    sendResponse({ success: true });
    return true;
  }
});
setInterval(updateExtensionIcon, 6e4);
console.log("Background script loaded");
//# sourceMappingURL=background.js.map
