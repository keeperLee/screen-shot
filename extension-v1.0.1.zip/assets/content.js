if (window.hasScreenshotExtension) {
  console.log("Screenshot content script already injected");
} else {
  console.log("Initializing screenshot content script...");
  Object.defineProperty(window, "hasScreenshotExtension", {
    value: true,
    enumerable: false,
    writable: false
  });
  async function captureFullPage() {
    console.log("开始截图...");
    try {
      const fullHeight = Math.max(
        document.documentElement.scrollHeight,
        document.body.scrollHeight
      );
      console.log("页面高度:", fullHeight);
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      const canvas = document.createElement("canvas");
      const context = canvas.getContext("2d");
      canvas.width = viewportWidth;
      canvas.height = fullHeight;
      const originalScroll = window.scrollY;
      const fixedElements = [];
      try {
        document.querySelectorAll("*").forEach((el) => {
          const style = window.getComputedStyle(el);
          if (style.position === "fixed" || style.position === "sticky") {
            fixedElements.push({
              element: el,
              originalPosition: el.style.position,
              originalTop: el.style.top,
              originalZIndex: el.style.zIndex,
              originalDisplay: el.style.display
            });
          }
        });
        window.scrollTo(0, 0);
        await new Promise((resolve) => setTimeout(resolve, 150));
        const firstScreenshot = await new Promise((resolve, reject) => {
          var _a;
          chrome.runtime.sendMessage({
            action: "captureVisibleTab",
            windowId: (_a = chrome.windows) == null ? void 0 : _a.WINDOW_ID_CURRENT
          }, (response) => {
            if (chrome.runtime.lastError || (response == null ? void 0 : response.error)) {
              reject(chrome.runtime.lastError || new Error(response.error));
            } else {
              resolve(response == null ? void 0 : response.dataUrl);
            }
          });
        });
        const firstImg = new Image();
        await new Promise((resolve, reject) => {
          firstImg.onload = resolve;
          firstImg.onerror = reject;
          firstImg.src = firstScreenshot;
        });
        context.drawImage(firstImg, 0, 0);
        fixedElements.forEach(({ element }) => {
          element.style.display = "none";
        });
        let currentHeight = viewportHeight;
        while (currentHeight < fullHeight) {
          console.log("当前滚动位置:", currentHeight);
          window.scrollTo(0, currentHeight);
          await new Promise((resolve) => setTimeout(resolve, 150));
          const dataUrl = await new Promise((resolve, reject) => {
            var _a;
            chrome.runtime.sendMessage({
              action: "captureVisibleTab",
              windowId: (_a = chrome.windows) == null ? void 0 : _a.WINDOW_ID_CURRENT
            }, (response) => {
              if (chrome.runtime.lastError || (response == null ? void 0 : response.error)) {
                reject(chrome.runtime.lastError || new Error(response.error));
              } else {
                resolve(response == null ? void 0 : response.dataUrl);
              }
            });
          });
          const img = new Image();
          await new Promise((resolve, reject) => {
            img.onload = resolve;
            img.onerror = reject;
            img.src = dataUrl;
          });
          const drawHeight = Math.min(viewportHeight, fullHeight - currentHeight);
          context.drawImage(
            img,
            0,
            0,
            // 源图像起点
            viewportWidth,
            drawHeight,
            // 源图像尺寸
            0,
            currentHeight,
            // 目标位置
            viewportWidth,
            drawHeight
            // 目标尺寸
          );
          currentHeight += drawHeight;
        }
      } finally {
        fixedElements.forEach(({ element, originalPosition, originalTop, originalZIndex, originalDisplay }) => {
          element.style.position = originalPosition;
          element.style.top = originalTop;
          element.style.zIndex = originalZIndex;
          element.style.display = originalDisplay;
        });
        window.scrollTo(0, originalScroll);
      }
      const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
      const url = URL.createObjectURL(blob);
      chrome.runtime.sendMessage({
        action: "downloadScreenshot",
        url
      }, () => {
        URL.revokeObjectURL(url);
      });
      console.log("截图完成");
    } catch (error) {
      console.error("截图过程出错:", error);
      throw error;
    }
  }
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("Content script收到消息:", request);
    if (request.action === "takeScreenshot") {
      captureFullPage().then(() => sendResponse({ success: true })).catch((error) => sendResponse({ error: error.message }));
      return true;
    }
  });
  console.log("Content script已加载");
}
//# sourceMappingURL=content.js.map
